// In App.js in a new project

import * as React from 'react';
import { View, Text, Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './HomeScreen';
import DetailsScreen from './Details';
import ThirdScreen from './ThirdScreen';
import Bonus from './bonus';



const Stack = createNativeStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="First Name" component={HomeScreen} />
        <Stack.Screen name="Details" component={DetailsScreen} />
        <Stack.Screen name="Third Screen" component={ThirdScreen} />
        <Stack.Screen name="Bonus" component={Bonus} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;